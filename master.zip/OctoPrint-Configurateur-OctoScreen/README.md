# OctoPrint-Z-Bolt-OctoScreen

<img width="480" src="https://user-images.githubusercontent.com/390214/69477910-07fb0600-0dfd-11ea-95be-46facb3328ba.png" />

Plugin Provides settings management for [OctoScreen](https://github.com/CyrilleSouchet/OctoScreen)

## Setup

Install manually via the bundled [Plugin Manager](https://plugins.octoprint.org/help/installation/)
using this URL:

    https://github.com/CyrilleSouchet/OctoPrint-Z-Bolt-OctoScreen/master.zip
